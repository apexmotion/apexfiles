#!/usr/bin/env python

import time
import sys
import logging

#for starting GUI
import subprocess
import os

#for reading recipes
import recipeReader

import xmlrpclib
from SimpleXMLRPCServer import SimpleXMLRPCServer

title = ""
LOCAL_HOST = "127.0.0.1"
DAEMON_PORT = 40404
ONVM = False

def set_title(new_title):
    global title
    title = new_title
    return title

def get_title():
    tmp = ""
    if str(title):
        tmp = title
    else:
        tmp = "No title set"
    return tmp + " (Python)"

def get_message(name):
    if str(name):
        return "Hello " + str(name) + ", welcome to PolyScope!"
    else:
        return "No name set"

#added by TJ Krawczynski April 2, 2019.
####################################################################
def listToPose(l):
    try:
        assert type(l) is list
    except (AssertionError):
        l = [0,0,0,0,0,0]
    return {'x' : l[0], 'y' : l[1], 'z' : l[2], 'rx' : l[3], 'ry' : l[4], 'rz' : l[5]}
def poseToList(p):
    assert type(p) is dict
    return [p['x'], p['y'], p['z'], p['rx'], p['ry'], p['rz']]
class Daemon:
    def __init__(self):
        self.GUIproc = None
        self.path = '/'
        self.recipeName = ''
        self.recipe = None
        self.recipeMaster = '' # the name of the app which last called 'chdir()'

        #create server
        self.server = SimpleXMLRPCServer((LOCAL_HOST, DAEMON_PORT), allow_none=True)
        #self.server = SimpleXMLRPCServer(("192.167.1.2", 8080), allow_none=True)
        #self.server = SimpleXMLRPCServer(("192.168.255.128", 8080), allow_none=True)

        #register functions
        self.server.register_function(self.startGUI, "startGUI")
        self.server.register_function(self.recipe_getRecipe, "recipe_getRecipe")
        self.server.register_function(self.recipe_getVar, "recipe_getVar")
        self.server.register_function(self.recipe_getPose, "recipe_getPose")
        self.server.register_function(self.recipe_getSubVar, "recipe_getSubVar")
        self.server.register_function(self.chdir, "chdir")
        self.server.register_function(self.recipe_master, "recipe_master")
        self.server.register_function(set_title, "set_title")
        self.server.register_function(get_title, "get_title")
        self.server.register_function(get_message, "get_message")
        
        logging.info("Initialized!")

    def start_server(self):
        #start server
        logging.info("Listening on port "+str(DAEMON_PORT)+"...")
        self.server.serve_forever()

    def startGUI(self, path='/home/scripts/Apex_startGUI'):
        #kill the old process if it exists
        if self.GUIproc != None:
          self.GUIproc.kill()

        #separate the path and exe
        self.path, filename = os.path.split(path)
        try:
            self.chdir(self.path)
        except OSError:
            logging.info('cannot start GUI, '+self.path+' does not exist')
            return 1
        #start the process
        logging.info("starting: " + filename + ' in: ' + self.path)
        self.GUIproc = subprocess.Popen(['./'+filename])
        return 0

    def chdir(self, path):
        os.chdir(path)
        self.path = path
        logging.info('operating out of: ' + self.path)

    ##### recipe functions #####

    #returns the name of the app responsible for the currently loaded recipe
    def recipe_master(self):
        logging.info('current recipeMaster: '+self.recipeMaster)
        return self.recipeMaster

    def recipe_getRecipe(self, in_recipeName, in_appName):
        recipeName = str(in_recipeName)
        appName = str(in_appName)
        logging.info('getRecipe("' + recipeName + '", "' + appName + '")')
        #check if file exists
        try:
            f = open(recipeName, 'r')
        except FileNotFoundError:
            logging.info('' +recipeName + ' not found in '+ self.path) 
            return 1
        f.close()
        
        #get recipe object
        logging.info('getting recipe object...')
        self.recipeName = recipeName
        self.recipe = recipeReader.BB_recipe(recipeName=self.recipeName)

        #change app identifier
        logging.info('assigning: recipeMaster = '+appName)
        self.recipeMaster = appName

        return 0
        
    def recipe_getVar(self, varName):
        return self.recipe.getVar(varName)
    
    def recipe_getPose(self, varName):
        return listToPose(self.recipe.getVar(varName))

    #only used for lists of poses
    def recipe_getSubVar(self, varName, index):
        return listToPose(self.recipe.getVar(varName)[index])

#initialize the logger
try:    
    logging.basicConfig(filename='/home/daemon.log',filemode='w',format='%(asctime)s %(message)s',level=logging.INFO)
except IOError:
    ONVM = True
    logging.basicConfig(filename='/home/ur/daemon.log',filemode='w',format='%(asctime)s %(message)s',level=logging.INFO)

##uncomment to also log to console
consoleHandler = logging.StreamHandler(sys.stdout)
logging.getLogger().addHandler(consoleHandler)
##

#sys.stdout.write("MyDaemon daemon started")
#sys.stderr.write("MyDaemon daemon started")

daemon = Daemon()
#logging.info('starting GUI')
#daemon.startGUI()
logging.info('starting daemon')
daemon.start_server()


####################################################################
##server = SimpleXMLRPCServer((LOCAL_HOST, DAEMON_PORT))
##server.register_function(set_title, "set_title")
##server.register_function(get_title, "get_title")
##server.register_function(get_message, "get_message")
##server.serve_forever()

