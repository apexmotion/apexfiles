#recipeRead takes a *.bbr recipe and turns it into an object for easy reading
import ast
import logging

#NOTE: recipeReader has been modified to use logging statements instead of print()

class BB_recipe():
    def __init__(self, recipeName='______', overwrite=False):
        self.recipeName = str(recipeName)
        self.vars = {}
        logging.info('initializing BB_recipe object')
        if overwrite == True:
            logging.info('no variables initialize for '+self.recipeName+', will overwrite any existing file on save')
            return
        try:
            recipeFile = open(self.recipeName, 'r')
        except FileNotFoundError:
            logging.info("recipeRead: file: '" + self.recipeName + "' not found, will create new file on save")
            return

        logging.info('initializing BB_recipe vars')
        #loop through the file line by line
        for line in recipeFile:
            if line == '\n':
                #print("recipeRead: skipping empty line")
                continue
            logging.info('interpreting line recipe entry: '+ line)
            
            #take out any comments at the end of the line
            unCommLine = line.split('#')
            #logging.info('-> "' + unCommLine[0] + '"')
            #take out all spaces and newline characters, then separate the string on the '='
            #strippedLine = unCommLine[0].translate({ord(c): None for c in " \n"})
            strippedLine = unCommLine[0].replace(' ', '').replace('\n', '')
            #logging.info('-> "' + strippedLine + '"')
            splitLine = strippedLine.split('=')
            #logging.info('-> "' + splitLine[0] + '" "' + splitLine[1] + '"')
            if len(splitLine) != 2:
                #if the line was not divided into two about an equal sign, ignore it
                logging.info("recipeRead: invalid line format: " + line + "... skipping line")
                continue

            #the old way
##            #if the second argument is a series of arguments, then write them as a list.
##            #if not, then just write the one value       
##            values = splitLine[1].translate({ord(c): None for c in "[]"}).split(',')
##            if len(values) > 1:
##                self.vars[splitLine[0]] = [float(i) for i in values]
##            else:
##                try:
##                    self.vars[splitLine[0]] = float(values[0])
##                    #print(values[0], 'interpreted as float')
##                except ValueError:
##                    #value error occurs when number is a string
##                    self.vars[splitLine[0]] = values[0]
##                    #print(values[0], 'interpreted as string')
            #the new way
            try:
                logging.info('attempting to read value as literal: '+splitLine[1])
                values = ast.literal_eval(splitLine[1])
                self.vars[splitLine[0]] = values
            except ValueError:
                #result is a string or boolean
                if splitLine[1] == 'True':
                    self.vars[splitLine[0]] = True
                elif splitLine[1] == 'False':
                    self.vars[splitLine[0]] = False 
                else:
                    self.vars[splitLine[0]] = splitLine[1]            

        recipeFile.close()
        logging.info('done creating recipe')
        #print(self.vars)

    # returns the value of the variable called 'var'
    def getVar(self, var, subIndex=-1):
        try:
            return self.vars[var]
        except KeyError:
            logging.info("recipeRead: variable name: '" + var + "'  not found in recipe")
            return 0
        except:
            logging.info("recipeRead: error reading data, might be non-existant")
            return 0

    # writes the value of variable called 'varName' to the recipe dictionary
    def setVar(self, varName, value):
        self.vars[varName] = value

    def delVar(self, varName):
        return self.vars.pop(varName, None)

    def saveAs(self, saveName):
        self.recipeName = saveName
        newFile = open(self.recipeName, 'w')
        for key, value in sorted(self.vars.items()):
            newFile.write(key + " = " + str(value) + '\n')
        newFile.close()

##testing stuff
#recipe = BB_recipe('Apps/TrayLoader/__default.bbr')
#print(recipe.vars)
